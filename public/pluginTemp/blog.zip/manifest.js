module.exports = {
  name: "Blog",
  description: "",
  options: {},
  version: "0.0.1",
  pages: {}
};
//# sourceMappingURL=manifest.js.map
