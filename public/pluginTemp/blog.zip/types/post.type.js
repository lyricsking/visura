"use strict";
//# sourceMappingURL=post.type.js.map
