"use strict";
//# sourceMappingURL=league.type.js.map
