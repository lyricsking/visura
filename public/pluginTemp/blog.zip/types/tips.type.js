"use strict";
export const PredictionType = {
  outcome: "outcome",
  scoreline: "scoreline"
};
//# sourceMappingURL=tips.type.js.map
